package com.proftelran.org.lessonone.homework;

public class Phone {
    private int number;
    private String model;
    private double weight;

    public void setNumber(int number) {
        this.number = number;
    }
    public int getNumber() {
        return number;
    }

    public void setModel(String model) {
        this.model = model;
    }
    public String getModel() {
        return model;
    }

    public void setWeight(double weight) {
    this.weight = weight;
    }
    public double getWeight() {
    return weight;
    }

    public void receiveCall (String name) {
        System.out.println(name + " calls");
    }
}
