package com.proftelran.org.lessonone.homework;

public class Person {
    private int age;
    private String name;
    private String fullName;

    public Person() {

    }

    public Person(String name, String fullName, int age) {
        this.name = name;
        this.fullName = fullName;
        this.age = age;
    }

    public void move() {
        System.out.println(fullName + " walks"); }

    public void talk() {
        System.out.println(fullName + " talks"); }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getFullName() {
        return fullName;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public int getAge() {
        return age;
    }

}
