package com.proftelran.org.lessonone.homework;

public class LessonOneHWApp {

    public static void main(String[] args) {
        Person john = new Person();
        john.setAge(38);
        john.setFullName("John Smith");
        john.setName("John");
        john.move();
        john.talk();

        Person mary = new Person ("Mary", "Mary Bell", 30);
        mary.move();
        mary.talk();

        Phone first = new Phone();
        first.setModel("iPhone");
        first.setNumber(343350);
        first.setWeight(70.8);
        System.out.println("The first phone has the following specifications: " + first.getModel() + ", " + first.getNumber() + ", " + first.getWeight() + " gr.");
        first.receiveCall("Mary");
        System.out.println(first.getNumber());

        Phone second = new Phone();
        second.setModel("Samsung");
        second.setNumber(511037);
        second.setWeight(100.3);
        System.out.println("The second phone has the following specifications: " + second.getModel() + ", " + second.getNumber() + ", " + second.getWeight() + " gr.");
        second.receiveCall("John");
        System.out.println(second.getNumber());

        Phone third = new Phone();
        third.setModel("Blackberry");
        third.setNumber(262876);
        third.setWeight(210.1);
        System.out.println("The third phone has the following specifications: " + third.getModel() + ", " + third.getNumber() + ", " + third.getWeight() + " gr.");
        third.receiveCall("Bob");
        System.out.println(third.getNumber());

    }
}
